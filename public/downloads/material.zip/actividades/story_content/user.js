function ExecuteScript(strId)
{
  switch (strId)
  {
      case "60xzDM6eO9f":
        Script1();
        break;
  }
}

function Script1()
{
  window.close();
}

